class EnviarEmail:

    def __init__(self):
        self.nome = None



    def teste(self, teste):
        print teste

    def gui (string):
        print "Guilherme Martino"
        return "oie"

    def setNome(self, nome):
        self.nome = nome

    def getNome(self):
        return self.nome
