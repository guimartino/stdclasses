class EnviarEmail:
    def teste(self, teste):
        print teste

    def gui (string):
        print "Guilherme Martino"