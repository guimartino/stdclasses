class EnviarEmail:
    def teste(self):
        print "testeee"