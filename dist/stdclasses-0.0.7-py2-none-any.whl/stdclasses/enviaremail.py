class EnviarEmail:
    def teste(self, teste):
        print teste